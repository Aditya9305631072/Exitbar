# Exitbar को मोबाइल से GitHub पर APK में Build करने की गाइड

## मोबाइल से APK कैसे बनाएँ?

1. GitHub पर लॉगिन करें और `Exitbar` नाम से नया repository बनाएँ।
2. इस ZIP को फोन में Extract करें।
3. Extract किए हुए `Exitbar_GitHub_Build_Project` फोल्डर के अंदर की सभी फाइलें repository के root में upload करें। `.github` नाम का hidden folder और उसके अंदर `workflows/android.yml` भी अवश्य upload करें।
4. GitHub repository में **Actions** टैब खोलें।
5. `Build Exitbar APK` workflow चुनें। `main` branch पर फाइलें push होते ही build शुरू होगा। जरूरत हो तो **Run workflow** दबाएँ।
6. Build पूरा होने पर workflow run खोलें और **Artifacts** में `Exitbar-debug-APK` डाउनलोड करें।
7. Artifact ZIP Extract करें। उसमें `app-debug.apk` मिलेगा। उसे फोन में install करें। जरूरत पड़ने पर Android की “Install unknown apps” अनुमति दें।

## Android Studio में बाद में
इसी source project ZIP को सुरक्षित रखें। Extract करके Android Studio में `Open` चुनें और project folder खोलें। Gradle JDK 17 चुनें। Project Gradle 8.9 और Android Gradle Plugin 8.7.3 के साथ configured है।

## इस शुरुआती संस्करण की सीमाएँ
- Camera बटन फोन के system camera app को खोलता है और अभी छोटा preview thumbnail लौटाता है।
- Photo Merge, Image to PDF, Resize, Crop, Converter, Compression और PDF Tools के कार्ड अभी UI placeholders हैं। इनकी वास्तविक processing अगले चरणों में जोड़ी जाएगी।
- Workflow अभी debug APK बनाता है। Play Store के लिए बाद में release signing और AAB configuration अलग से करेंगे।
- पहली build में GitHub runner को internet से Gradle और Android dependencies डाउनलोड करनी होंगी।

GitHub Actions build अपने-आप GitHub का logo या विज्ञापन APK में नहीं जोड़ता। ऐप में शामिल सामग्री project source पर निर्भर है।
