# Exitbar Base Project

यह Exitbar का शुरुआती Android Studio प्रोजेक्ट है।

## इस संस्करण में क्या काम करता है?
- Jetpack Compose आधारित Home Screen
- सबसे ऊपर बड़ा Camera विकल्प
- Camera विकल्प Android के उपलब्ध Camera ऐप को खोलता है
- Camera से लौटने पर thumbnail preview दिखता है
- Light / Dark Theme toggle
- Hindi / English toggle
- Tools, My Files और Settings के शुरुआती स्क्रीन

## जरूरी सेटअप
- Android Studio (एक हालिया स्थिर संस्करण)
- JDK 21 (Android Studio का Embedded JDK भी चुन सकते हैं)
- Android SDK Platform 35
- इंटरनेट: पहली बार Gradle dependencies डाउनलोड करने के लिए

## Android Studio में कैसे खोलें?
1. ZIP को Extract करें।
2. Android Studio खोलें।
3. `Open` चुनें और Extract किया हुआ `Exitbar_Base_Project` फोल्डर चुनें।
4. Gradle Sync पूरा होने दें।
5. Android फोन में Developer Options और USB Debugging चालू करके USB से जोड़ें, या Emulator चुनें।
6. ऊपर Run ▶ दबाएँ।

## ध्यान दें
यह Phase 1 Base UI है। Camera अभी सिस्टम Camera ऐप के माध्यम से thumbnail capture करता है। अगली Phase में हम ऐप के अंदर CameraX preview, full-resolution photo saving, crop, gallery picker, PDF generation और share flow जोड़ेंगे।
Image/PDF टूल कार्ड फिलहाल UI placeholders हैं; वे अभी processing नहीं करते।

## Gradle / JDK
Project Android Gradle Plugin 8.7.3, Kotlin 2.0.21 और Compose Compiler Plugin का उपयोग करता है।
Gradle Sync में JDK 17 या 21 चुनें; JDK 21 अनुशंसित है।


मोबाइल से GitHub Build के लिए `GITHUB_BUILD_GUIDE_HI.md` पढ़ें। Workflow: `.github/workflows/android.yml`।
